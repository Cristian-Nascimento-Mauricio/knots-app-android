package com.example.knotsapp.interfaces

import android.content.Context

interface AddSwitchKnotMethods {

    fun switchKnot(context: Context , name:String , activied:Boolean)

}