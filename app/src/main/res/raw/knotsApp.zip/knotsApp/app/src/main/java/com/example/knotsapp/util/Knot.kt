package com.example.knotsapp.util

class Knot (){
    var name:String? = null
    var type:String? = null
    var time:Int? = null
    var score:Int? = null
    var description:String? = null
    var activated:Boolean = true

}